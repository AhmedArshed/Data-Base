use employees

 insert into departments (dept_no , dept_name) values(102 ,'EE');
 insert into departments (dept_no , dept_name) values(103 ,'BBA');
 insert into departments (dept_no , dept_name) values(101 ,'CS');
select *from departments;
insert into employees (emp_no , birth_date , first_name , last_name , gender , hire_date) values (11 , '1998-03-23' , 'ahmed' , 'arshed' , 'M' , '2020-03-30');
insert into employees (emp_no , birth_date , first_name , last_name , gender , hire_date) values (12 , '1996-03-23' , 'waleed' , 'arshed' , 'M' , '2018-03-30');

insert into dept_emp (emp_no , dept_no , from_date , to_date) values(12 , 103 , '1900-02-12' , '2000-05-28');
insert into dept_emp (emp_no , dept_no , from_date , to_date) values(11 , 101 , '2000-02-12' , '2019-02-28');

insert into salaries (emp_no,salary , from_date,to_date) values(11 , 100000 , '2000-02-12' , '2019-02-28');
insert salaries(emp_no , salary , from_date , to_date) values(12 , 200000 , '1890-01-15' , '1990-05-1');

insert into titles (emp_no , title , from_date , to_date) values(11 , 'Manager' , '2000-02-12' , '2019-02-28');
insert into titles (emp_no , title , from_date , to_date) values(12 , 'Second Manager' , '2000-02-12' , '2019-02-28');
select *from titles;

 insert into dept_manager(dept_no , emp_no , from_date , to_date) values(101 , 11 , '2000-02-12' , '2019-02-28');
insert into dept_manager(dept_no , emp_no , from_date , to_date) values(102 , 12 , '2000-02-12' , '2019-02-28');
select *from dept_manager;


-- Q2
 select* from dept_emp;
 update dept_emp
    set
    dept_no = 103
    where emp_no = 11;
update salaries
    set
    salary = 300000
    where salary < 200000;
select *from salaries;

 update  departments
    set
    dept_name = 'humanities'
    where dept_no = 103;
 update titles
    set
    title = 'Assistant Manager'
    where emp_no = 11;
select *from titles;

update employees
    set
    hire_date = '2025-03-12'
    where first_name = 'ahmed';

--Q3
delete from employees
    where hire_date < '2020-05-9';

select *from employees;

delete from departments;
 select* from departments;

delete from salaries
    where salary >100000;
select*from salaries;
