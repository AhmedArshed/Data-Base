<?php 
include "connect.php";

$code = $_POST["codes"];
$name = $_POST["names"];
$hour = $_POST["hours"];

 $qry = "INSERT INTO courses VALUES('".$code."','".$name."', '".$hour."')";

 ?>