create table courses(
	course_code char(4) primary key,
	course_name varchar(12) not null,
	credit_hours int(1) not null);

create table enroll(
	course_code char(4) not null,
	roll_no varchar(10) not null,
	constraint fk_code foreign key(course_code)
 		 references courses(course_code),
	constraint fk_roll_no foreign key(roll_no)
		references student(roll_no),
	constraint pk_enroll primary key(course_code , roll_no));