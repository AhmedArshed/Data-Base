<!DOCTYPE html>
<html>
		<head>
			<title>Courses Registration </title>
		</head>
	<body>
		<h4>Courses Registration table</h4>
			<form action="connect_try.php" method="post">
				<table align="center">
					<th colspan="2"></th>
								<tr>
									<td>
	 								 Course Code:
	 								</td>
	 									<td>
	  									<input type="text" name="codes"></td>
								</tr>
								<tr>
									<td>
									  Course Name:
									</td>
									<td>
	 									 <input type="text" name="names" required>
									</td>
								</tr>
								<tr>
									<td>
										credit hours:
									</td>
									<td>
										  <input type="text" name="hours" required>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="right">
										<input type="submit" value="Register">
									</td>
								</tr>
								<tr>
									<td colspan="2">
										<?php
											if (isset($_GET["Message"])) {
												echo $_GET["Message"];
											}
										?>
									</td>
								</tr>
							</table>
						</form>
	</body>
</html>