<?php
include "connect.php";
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Search Student</title>
</head>
	<body>
			<form action="" method="post">
				<table align="center">
					<th colspan="2">Search Student</th>
						<tr>
							<td>
								Roll No
							</td>
							<td>
								<input type="text" name="search" required>
							</td>
						</tr>
						<tr>
							<td colspan="2" align="right">
								<input type="submit" value="Search">
							</td>
						</tr>
				</table>
			</form>
	<?php
		if (isset($_POST["search"])) {
			$roll = $_POST["search"];
			$qry = "SELECT * FROM student WHERE roll_no = '".$roll."'";
			$res = $con->query($qry);
			$result = "";

			if ($res->num_rows>0) {
				$result .= "<table align='center'>";
				$result .= "<th>Roll No</th><th>Name</th><th>Father's Name</th><th>Gender</th><th>Contact No</th><th>Address</th>";
				while ($row = $res->fetch_assoc()) 
				{
					//one row
					$result .= "<tr>
									<td>
										".$row['roll_no']."
									</td>
									<td>
										".$row['st_name']."
									</td>
									<td>
										".$row['f_name']."
									</td>
									<td>
										".$row['gender']."
									</td>
									<td>
										".$row['contact']."
									</td>
									<td>
										".$row['address']."
									</td>
								</tr>";
				}
				$result .= "</table>";
			}
			echo $result;


		$qrys = "SELECT * FROM courses WHERE course_code in (SELECT course_code FROM enroll WHERE roll_no = '".$roll."')";
		$res = $con->query($qrys);
			$results = "";
			$results.= "<h3 align='center'>Registor Courses</h3>";
			if ($res->num_rows>0) {
				$results .= "<table align='center'>";
				$results .= "<th>Code</th><th></th><th></th><th>Name</th><td></td><th>
								Credits</th>";
				while ($arow = $res->fetch_assoc()) 
				{
					$results .= "<tr>
									<td>
										".$arow['course_code']."
									</td>
									<td></td>
									<td></td>
									<td>
										".$arow['course_name']."
									</td>
									<td></td>
									<td>
										".$arow['credit_hours']."
									</td>
									<td>
									</td>
								</tr>";
				}
				$results .= "</table>";
			}
			echo $results;

// $qryz = "SELECT a.course_code , a.course_name , a.credit_hours from courses a, enroll b,student s where s.roll_no = b.roll_no and b.courses_code != a.courses_code";
$qryz = "SELECT * FROM courses WHERE course_code != all (SELECT course_code FROM enroll WHERE roll_no = '".$roll."')";
// $qryz = "SELECT "
		$res = $con->query($qryz);
			$resultz = "";
			$resultz.= "<h3 align='center'>Available Courses</h3>";
			if ($res->num_rows>0) {
				$resultz .= "<form method = post> <table align='center'>";
				$resultz .= "<th>Code</th><th></th><th></th><th>Name</th><td></td><th>
								Credits</th>";
				while ($brow = $res->fetch_assoc()) 
				{
					$resultz .= "<tr>
									<td>
										".$brow['course_code']."
									</td>
									<td></td>
									<td></td>
									<td>
										".$brow['course_name']."
									</td>
									<td></td>
									<td>
										".$brow['credit_hours']."
									</td>
									<td>
									</td>
									<td>
									<input type= submit value= Registor>
									</td>
								</tr>";
				}
				$resultz .= "</table></form>";
			}
			echo $resultz;
		}

	?>
	</body>
</html>